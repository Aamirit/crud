<!DOCTYPE html>
<html>
   <head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
   </head>
   <body>
      <div class="container">
         <div class="row">
            <a href="<?php echo e('/'); ?>">Register </a>&nbsp&nbsp
         </div>
         <h2>Table</h2>
         <p>The .table-responsive class creates a responsive table which will scroll horizontally on small devices (under 768px). When viewing on anything larger than 768px wide, there is no difference:</p>
         <div class="table-responsive table-striped">
            <table class="table">
               <thead>
                  <tr>
                     <th>#</th>
                     <th>Name</th>
                     <th>Email</th>
                     <th>Address</th>
                     <th>Zip</th>
                     <th>State</th>
                     <th>Actions</th>
                  </tr>
               </thead>
               <tbody>
                  <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                     <td><?php echo e($customer->id); ?></td>
                     <td><?php echo e($customer->name); ?></td>
                     <td><?php echo e($customer->email); ?></td>
                     <td><?php echo e($customer->address); ?></td>
                     <td><?php echo e($customer->zip); ?></td>
                     <td><?php echo e($customer->state); ?></td>
                     <td>
                        
                        
                        <form  id="editForm">
                           <?php echo csrf_field(); ?>
                           <button type="submit" id="editsbmt" data-id="<?php echo e($customer->id); ?>">Edit</button>
                           
                        </form>
                        <form id="deletefrm">
                           <?php echo csrf_field(); ?>
                           <button type="submit" id="deletedata" data-id="<?php echo e($customer->id); ?>">Delete</button>
                           
                        </form>
                     </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </tbody>
            </table>
         </div>
      </div>
      
      <!-- Modal -->
      <div class="modal fade" id="myModal" role="dialog">
         <div class="modal-dialog  modal-lg">
            <!-- Modal content-->
            <div class="modal-content">
               <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Update Data</h4>
               </div>
               <div class="modal-body">
                  <form id="rgstr_form">
                     <div class="success"></div>
                     
                     <?php echo csrf_field(); ?>
                     <div class="row">
                        <div class="form-group col-md-6">
                           <label for="usr">Name:</label>
                           <input type="text" class="form-control name" id="usr" name="name">
                           <span class="name_error all_errors">&nbsp;</span>
                        </div>
                        <div class="form-group col-md-6">
                           <label for="email">Email:</label>
                           <input type="email" class="form-control email" id="email" placeholder="Enter email" name="email">
                           <span class="email_error all_errors">&nbsp;</span>
                        </div>
                        <input type="hidden" class="form-control password" id="password" placeholder="Enter password" name="password">
                        
                        <div class="form-group col-md-6">
                           <label for="address">Address:</label>
                           <input type="text" class="form-control address" id="address" name="address">
                           <span class="address_error all_errors">&nbsp;</span>
                        </div>
                        <div class="form-group col-md-6">
                           <label for="zip">Zip:</label>
                           <input type="text" class="form-control zip" id="zip" name="zip">
                           <span class="zip_error all_errors">&nbsp;</span>
                        </div>
                        <div class="form-group">
                           <label for="state">Statae</label>
                           <select class="form-control state" id="state" name="state">
                              <option value="punjab">Punjab</option>
                              <option value="sindh">Sindh</option>
                              <option value="kpk">KPK</option>
                              <option value ="balochistan">Balochistan</option>
                           </select>
                           <span class="state_error all_errors"></span>
                        </div>
                        <br>
                        
                        <input type="hidden" class="id" name="id" >
                        <button type="submit" id="sbmit" class="btn btn-default">Submit</button>
                     </div>
                  </form>
               </div>
               <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
               </div>
            </div>
         </div>
      </div>
      
      <script type="text/javascript">
         $(document).ready(function() {
            $(document).on("click","#editsbmt",function(e) {
          e.preventDefault();
             var id = $(this).attr("data-id");
             var _token = $('#editForm input[name="_token"]').val();
             $.ajax({
               type: "POST",
               url: "<?php echo e(route('customeredit')); ?>",
               dataType: "json",
               data: {id,_token},
               success : function(data){
               $('#myModal').modal('show'); 
               $('.name').val(data.name);
               $('.email').val(data.email);
               $('.password').val(data.password);
               $('.cnfrm_pswd').val(data.password);
               $('.address').val(data.address);
               $('.zip').val(data.zip);
               $('.state').val(data.state);
               $('.id').val(data.id);
              console.log(data);
              }
           });
         
         });
         });
      </script>
      
      <script type="text/javascript">
         $(document).ready(function() {
         
            $(document).on("click","#sbmit",function(e) {
          e.preventDefault();
               $('.all_errors').empty();
          $.ajax({
             type: "POST",
             url: "<?php echo e(route('updateuser')); ?>",
             dataType: "json",
             data: $('form').serializeArray(),
             success : function(data){
              // console.log(data.errors);
             //  $('#rgstr_form').trigger('reset');
               if(data.response == true){
                swal({
                  title: "Congratulations?",
                  text: data.success,
                  icon: "success"
                })
                .then((value) => {
                  if (value) {
                    window.location.replace(data.redirect);
                  }
                });
                  // $('.success').text(data.success);
                  // window.location.replace(data.redirect);
               }else {
               if(data.errors){
                  $('.name_error').text(data.errors.name);
                  $.each(data.errors, function (key, value) {
         $('.' + key + '_error').html(value);
         });
              
               }
               // console.log(data);
              
             }}
           });
         
         });
         });
      </script>


  
      <script type="text/javascript">
         $(document).ready(function() {
            $(document).on("click","#deletedata",function(e) {
          e.preventDefault();
             var id = $(this).attr("data-id");
             var _token = $('#deletefrm input[name="_token"]').val();

           swal({
                    title: "Are you sure?",
                    text: "Once deleted, you will not be able to recover this Data!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                  })
                  .then((value) => {
                    if (value) {
                      $.ajax({
                      type: "POST",
                      url: "<?php echo e(route('deletecustomer')); ?>",
                      dataType: "json",
                      data: {id,_token},
                      success : function(data){
                        if(data.response == true){   
                          window.location.replace(data.redirect);
                      }     
                      }
                  });
                    } else {
                      swal("Your imaginary file is safe!");
                    }
                  });




         });
         });
      </script>

   </body>
</html>
<?php /**PATH F:\crud\resources\views/viewdata.blade.php ENDPATH**/ ?>